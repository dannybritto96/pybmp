# Py BMP

Python package to read a BMP file's header and pixel array in binary.

## Usage

